1:undefiend mane akkhono vitore kicu dawya hoy nai 
ar null mane hoilo vitore khali
2: for ecah amra prottek ta dhore dhore kaj korbo kintu output lagne na
 ar map() prottek ta k dhore dhore kicu kore amak akta result dibe
 3:== ata shudu check korbe jea man shoman naki kintu === ata check korbe tar man and ar type same naki
 4:async`/`await ata amak data nawayr jonno w8 korte bole
 5: ar answer ta bujttaci na